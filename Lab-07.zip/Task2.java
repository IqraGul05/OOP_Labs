import java.util.Scanner;
    class Task2{
    public static void main(String[] args){
         
        Scanner input = new Scanner(System.in);
        System.out.println("Enter String: ");
        String letter = input.nextLine();

            int index = letter.indexof("a");
        System.out.println ("Index of a is: " + index);
}
}