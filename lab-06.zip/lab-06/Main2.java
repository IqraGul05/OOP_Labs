class main2{
    public static void main(String args []){

 GraduateStudent G= new GraduateStudent("Iqra Gul",20,"F24ari147","AI");
 
    G.displayInfo();
        
    }
}