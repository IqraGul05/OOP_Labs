class Main3{
    public static void main(String args []){
   Car C = new Car("KIA", 90, 5);
   C.showDetails();
   System.out.println();
   Bike B = new Bike("125", 70, "Covered");
B.showDetails();

        
    }
    
}