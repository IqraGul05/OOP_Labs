class main{
    public static void main(String args []){
    Dog sound = new Dog(" Puppy ,", 6);
    sound.displayInfo();
    System.out.println();
    sound.makeSound();
        
    }
}