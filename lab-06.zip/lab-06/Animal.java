class Animal{
    String name ;
    int age ;
    Animal(String name , int age){
        this.name=name;
        this.age=age;
    }
    
    public void makeSound(){
        System.out.println("Animal is making a sound .");
    }
    void displayInfo(){
        System.out.println("Name : "+name+" Age :"+age);

    }
    
}