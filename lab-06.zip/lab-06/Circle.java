class Circle extends Shape{
	public void draw(){
		
		System.out.println("Drawing a Circle .");

	}
}