public interface TaxPayer{
    void payTax (double salary);
}