public class Duck implements Flyable, Swimmable{
  
  public void fly(){
     System.out.println("Duck is Flying");
}

public void swim(){
  System.out.println ("Duck is swimming");
}
}