class ICICI extends Bank {
    
    double getInterestRate() {
        return 8.2;
    }
}
