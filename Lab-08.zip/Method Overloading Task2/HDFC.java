class HDFC extends Bank {
    
    double getInterestRate() {
        return 6.8;
    }
}